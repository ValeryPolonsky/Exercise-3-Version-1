package controller;

/**
 * <h1> Class Command</h1>
 * This class will be a "parent" class of commands that will be created
 * 
* @author Valery Polonsky & Tomer Dricker
 *
 */
public interface Command<T> { 
	void doCommand(T[] data);
}
