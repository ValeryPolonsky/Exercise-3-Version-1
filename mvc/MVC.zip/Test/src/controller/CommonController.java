package controller;

import java.util.HashMap;
import java.util.HashSet;

import model.Model;
import view.View;

/**
 * <h1> Class Common Controller </h1>
 * This class has three data members - to set up a connection between Model and View<br>
 * 1) Model model - this class get a problem and generates a solution<br>
 * 2) View view  - this class displays a solution and gets commands from the user<br>
 * 3) HashMap<String,Command> commands - String: saves the command name, Command: generation of the command<br>
 * 
 * 
 * @author Valery Polonsky & Tomer Dricker
 *
 */
public abstract class CommonController implements Controller {
	Model model;
	View view;
	HashMap<String, Command<String>> commands;
	
	/**
	 * Initialize the Controller Fa�ade instance
	 */
	public CommonController() {
		commands = new HashMap<String, Command<String>>();
		initCommands();
	}
	
	public void setModel(Model model) {
		this.model = model;
	}
	
	public void setView(View view) {
		this.view = view;
		view.setCommands(new HashSet<String>(commands.keySet()));
	}
	
	/**
	 * Override this to initialize the commands supported by this implementation
	 * of the Controller Fa�ade
	 */
	protected abstract void initCommands();

	@Override
	public void doCommand(String command, String[] data) {
		commands.get(command).doCommand(data);
	}
}
