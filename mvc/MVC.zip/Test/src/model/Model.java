package model;

/**
 * <h1> Class Model </h1>
 * The model is the main part of the calculation,
 * when the view need to do something he calls controllers and controllers 
 * call the model to do it.
 * When the model end it's activity it tells to the view through controller.
 * 
 * @author Valery Polonsky & Tomer Dricker
 *
 */
public interface Model {
	
	/**
	 * Aborts any threads waiting for execution, and block until all currently
	 * executing threads finish their execution
	 */
	void stop();
	
	/**
	 * Calculate the list of files under the given directory path
	 * @param path Path of a directory
	 */
	void calculateFileList(String path);
	
	/**
	 * Generate a new 3d maze
	 * @param mazeName Name for the new maze
	 * @param length Length of the maze
	 * @param height Height of the new maze
	 * @param width Width of the maze
	 */
	void generate3DMaze(String mazeName,int length,int height,int width);
	
	/**
	 * Gets a named 3d maze
	 * @param mazeName Name of the 3d maze 
	 */
	void get3DMaze(String mazeName);
	
	/**
	 * Gets a cross section of the 3d maze
	 * @param mazeName Name of the maze
	 * @param axis Axis of the cross section
	 * @param index Index of the cross section
	 */
	void getCrossSection(String mazeName, String axis,int index);
	
	/**
	 * Saves a named maze in the given file
	 * @param name Name of the maze
	 * @param fileName Path + name of the file
	 */
	void saveMaze(String mazeName,String fileName);
	
	/**
	 * Load a maze from a given file and give it a name
	 * @param fileName Path + name of the file
	 * @param name Name for the loaded maze
	 */
	void loadMaze(String fileName,String mazeName);
	
	/**
	 * Calculate the size of a named maze
	 * @param name Name of the maze
	 */
	void calculateMazeSize(String mazeName);
	
	/**
	 * Calculate the compressed size of a named maze
	 * @param name Name of the maze
	 */
	void calculateFileSize(String fileName);
	
	/**
	 * Solve a named maze using the named algorithm
	 * @param name Name of the maze
	 * @param algorithmName Name of the algorithm
	 */
	void solveMaze(String mazeName,String algorithmName);
	
	/**
	 * Get the solution for a named maze 
	 * @param name Name of the maze
	 */
	void getSolution(String mazeName);
}
