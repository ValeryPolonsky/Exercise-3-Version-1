package view;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.HashSet;
import controller.Controller;

/**
 * <h1> Class CLI </h1>
 * This class is responsible to get correct user input & sending it to the Controller.
 * @author Valery Polonsky & Tomer Dricker
 */
public class CLI{
	Controller controller;
	private BufferedReader in;
	private PrintWriter out;
	HashSet<String> commands; //HashMap<String,Command<String>> commands;
	
	/**
	 * Initialize the CLI
	 * @param controller Controller Fa�ade instance
	 * @param in Input reader
	 * @param out Output writer
	 */
	public CLI(Controller controller, BufferedReader in, PrintWriter out) {
		this.in = in;
		this.out = out;
		this.controller = controller;
	}
	/**
	/**
	 * Set the list of commands supported by the Controller Fa�ade instance
	 * @param commands List of commands
	 */
	public void setCommands(HashSet<String> commands) {
		this.commands = commands;
	}

	public void start() throws IOException{
	Thread t=new Thread(new Runnable(){
	@Override
	public void run() {
		printInstructions();
		String input = "";
		try {
		while(true) // Another Option is: "String line; while(!(line=in.readLine()).equals("exit")){
		{
			System.out.print(">>> ");
			input=in.readLine();
			String[] splitedInput=input.split(" "); 
			if(splitedInput[0].equals("exit")||splitedInput[0].equals("Exit"))
			{
				controller.stop();
				out.print("Have a nice day!");
				out.flush();
				break;
			}
			else if(splitedInput[0].equals("help")||splitedInput[0].equals("Help")){
				printInstructions();
			}
			if(commands.contains(splitedInput[0]))
			{
				controller.doCommand(splitedInput[0], Arrays.copyOfRange(splitedInput, 1, splitedInput.length));
			}
			else
			{
				System.out.println("This command doesn't exist, please try again!");
			}
		}
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}
	});
	t.run();
	}
	/**
	 * Display a message to the user
	 * @param message The message
	 */
	public void display(Object message) {
		out.print(message);
		out.flush();
	}

	/**
	 * Display a line break to the user
	 */
	public void displayLine() {
		out.println("");
		out.flush();
	}

	/**
	 * Display a message to the user, followed by a line break
	 * @param message The message
	 */
	public void displayLine(Object message) {
		out.println(message);
		out.flush();
	}
	
	private void printInstructions()
	{
		System.out.println("****** LIST OF AVAILABLE FUNCTIONS ******");
		System.out.println("1) generate3dMaze <maze name> <length> <height> <width>");
		System.out.println("2) display <maze name>");
		System.out.println("3) displayCrossSection <maze name> <axis> <index>");
		System.out.println("4) saveMaze <maze name> <file name>");
		System.out.println("5) mazeSize <maze name>");
		System.out.println("6) fileSize <file name>");
		System.out.println("7) solve <maze name> <algorithm>");
		System.out.println("8) displaySolution <maze name>");
		System.out.println("9) dir <path>");
		System.out.println("10)loadMaze <file name> <maze name>");
		System.out.println("11)exit");
		System.out.println("12)Lost? write 'help'.\n");
	}
}
