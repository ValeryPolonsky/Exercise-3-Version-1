package view;

import java.util.HashSet;

import algorithms.search.Solution;


/**
 * <h1> Class View </h1>
 * display all the solutions/messages from Controller
 * 
 * @author Valery Polonsky & Tomer Dricker
 *
 */
public interface View {
	
	/**
	 * Starts the user interface
	 */
	void start();
	
	/**
	 * Set the list of commands supported by the Controller Fa�ade instance
	 * @param commands List of commands
	 */
	void setCommands(HashSet<String> commands);
	
	/**
	 * Displays an error
	 * @param errorMsg Error message
	 */
	void displayError(String erorMsg);
	
	/**
	 * Displays a list of files
	 * @param list The list of files
	 */
	void displayFiles(String[]listOfFiles);
	
	/**
	 * Displays a 3d maze
	 * @param mazeData Maze compressed data
	 */
	void display3DMaze(byte[]maze);
	
	/**
	 * Displays a cross section of a 3d maze
	 * @param crossSection Cross section data
	 */
	void displayCrossSection(int[][]section);
	
	/**
	 * Displays the size of a maze
	 * @param size The size
	 */
	void displayMazeSize(int size);
	
	/**
	 * Displays the compressed size of a maze
	 * @param size Compressed size
	 */
	void displayFileSize(int size);
	
	/**
	 * Displays the solution of a maze
	 * @param solution The solution
	 */
	void displaySolution(Solution solution);
	
	/**
	 * Displays that a maze was generated
	 * @param mazeName Name of the generated maze
	 */
	void displayMazeReady(String mazeName);
	
	/**
	 * Display that a maze was saved successfully
	 * @param name Name of the saved maze
	 */
	void display3DMazeSaved(String mazeName);
	
	/**
	 * Display that a maze was loaded successfully
	 * @param mazeName Name of the loaded maze
	 */
	void display3DMazeLoaded(String mazeName);
	
	/**
	 * Display that a solution is ready for a maze
	 * @param mazeName Name of the maze
	 */
	void displaySolutionReady(String mazeName);
	
	/**
	 * Display the the application is shutting down
	 */
	void displayShuttingDown();
	
	/**
	 * Display that the application has shut down
	 */
	void displayShutDown();
}